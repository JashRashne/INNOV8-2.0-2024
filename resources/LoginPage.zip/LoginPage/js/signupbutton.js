function signUp(){
    document.querySelector(".signup-button").addEventListener("click", () =>{
        window.location.replace("index-signup.html");
    });

}